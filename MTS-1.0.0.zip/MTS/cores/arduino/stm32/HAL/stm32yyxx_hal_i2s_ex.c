#ifdef STM32F3xx
#include "stm32f3xx_hal_i2s_ex.c"
#endif
#ifdef STM32F4xx
#include "stm32f4xx_hal_i2s_ex.c"
#endif
#ifdef STM32H7xx
#include "stm32h7xx_hal_i2s_ex.c"
#endif
