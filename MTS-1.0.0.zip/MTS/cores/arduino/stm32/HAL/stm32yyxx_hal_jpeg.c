#ifdef STM32F7xx
#include "stm32f7xx_hal_jpeg.c"
#endif
#ifdef STM32H7xx
#include "stm32h7xx_hal_jpeg.c"
#endif
